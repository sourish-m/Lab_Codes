lst = []
lst2=[]
 
n = int(input("Enter number of elements : "))
 
for i in range(0, n):
    num = int(input())
    lst.append(num) 
     

for n in lst:
    Reverse = 0    
    while(n > 0):    
        Reminder = n %10    
        Reverse = (Reverse *10) + Reminder    
        n= n //10
    lst2.append(Reverse)

tuple1 = tuple(lst2)
print(tuple1)

tuple2= tuple(sorted(tuple1))
print("Sorted tuple\n",tuple2)

tuple3= tuple1 + tuple(lst)
tuple3= (tuple(sorted(tuple3)))
print ("Merged tuples:\n",tuple3)
