
ls = [[(4, 5), (7, 8)], [(10, 13), (18, 17)], [(0, 4), (10, 1)]]


print("The original list is : " + str(ls))


temp = [ele for sub in ls for ele in sub]


r = list(zip(*temp))


print("The converted tuple list : " + str(r))
