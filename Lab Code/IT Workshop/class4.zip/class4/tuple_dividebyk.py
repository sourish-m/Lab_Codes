tuple1=(10,12,14,15)
lst=[]
k= int(input("Enter element k: "))

for x in tuple1:
    if x%k==0:
        lst.append(x)

print(tuple(lst))
