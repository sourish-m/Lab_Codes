str = input ("Enter a string: ")

def first_3_letters(str):

    if len(str)<3:
        return str
    else:
        return str[0:3]

print("New String is:",first_3_letters(str))
