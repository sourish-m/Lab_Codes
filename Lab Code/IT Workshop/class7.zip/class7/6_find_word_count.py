s = "This is a new string a"
str2=[]
count = 0

for i in s.split():
    str2.append(i)

for i in str2:
    
    print("The word ",i," occurs ",str2.count(i)," times.")
