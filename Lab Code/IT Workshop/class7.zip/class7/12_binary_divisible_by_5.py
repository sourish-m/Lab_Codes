nums = list(input("enter 4 digit binary numbers :\n").split(','))


r = [num for num in nums if not int(num, 2) % 5]

print("Numbers divisible by 5 are:",r)

