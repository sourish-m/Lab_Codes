for i in range(0,6):
    if (i==3 or i==6):
        continue
    else:
        print(i)
