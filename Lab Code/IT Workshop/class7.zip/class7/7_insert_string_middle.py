str = "This is a sample string"

def string_middle_add (str):
    l = len(str)//2
    str2 = input ("Enter the string to insert: ")
    str3 = str[0:l] + " " + str2 +" " + str[l:len(str)]
    return str3

print ("New String is: ",string_middle_add(str))
