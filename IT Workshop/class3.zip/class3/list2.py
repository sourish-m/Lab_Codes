list3= [1,4,7,3,5,8,6,2]

for i in range(len(list3)):
    min=i

    for j in range (i+1,len(list3)):
        if list3[j]<list3[min]:
            min=j
            (list3[i],list3[min])=(list3[min],list3[i])

list3.sort()
print ("Sorted array is:",list3)


