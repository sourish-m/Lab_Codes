
list1=[1,1,2,3,4,4]
r= []
for i in list1:
    if i not in r:
        r.append(i)
  
print ("The list after removing duplicates : " + str(r))
