list1= [1,1,2,2,3,3,3,4,4,4,4,5]
freq=[0]*len(list1)

for i in list1:
    freq[i]=freq[i]+1

for i in range(len(list1)):
    if freq[i]>0:
        print(f"{i} appears {freq[i]} times")
