list3=[1,3,5,2,7,5,8]

l=int(len(list3)/2)
print(l)
temp=0
i=0
while (i<=l):
    temp=list3[l-i]
    list3[l-i]=list3[l+i]
    list3[l+i]=temp
    i = i +1
print ("Rotated list",list3)
