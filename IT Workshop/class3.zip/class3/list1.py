list1 = [0,1,2,3,4,5,6,7,8]
list2 = []
for i in list1:
    if i%2!=0:
        list2.append(i)
print (list2)

list3 = list2 + list1
list3.sort()
print (list3)



