list1=[1,2,7,5,3,4,9,10,11]
list2=[]
print("Enter number of consecutive elements to remove")
k = int(input())
i=0
while (i <= len(list1)-k):
    j=0
    count=0
    while (j<k-1):
        if list1[i+j] + 1 == list1[i+j+1] :
            count = count + 1
        j = j + 1

    if count == k-1:
        i = i + k
    
    else:
        list2.append(list1[i])
        i = i + 1

print (list2)

