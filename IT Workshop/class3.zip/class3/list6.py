list =  ['this','is','a','string']
print("Enter element to print")
i = int(input())
print(list[i-1])
