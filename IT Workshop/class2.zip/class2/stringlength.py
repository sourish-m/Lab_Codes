str1 = 'Sourish'
str2 = 'Mandal'

j=0
for i in str1:
    j=j+1
print (j)

def strlength(a,b):
    for num in range(j):
        if a[num]>b[num]:
            print (a)
            break
        else:
            print (b)
            break
strlength (str1, str2)
