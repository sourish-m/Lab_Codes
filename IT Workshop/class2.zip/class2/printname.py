str = 'Sourish Mandal'
print (str[0])
print (str[2:5])
print (str[2:])
print (str*2)
print (str + "test")
