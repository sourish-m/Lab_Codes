firstname = 'Sourish'
middlename = 'Ramesh'
lastname = 'Rajesh'
print (firstname + ' ' + middlename + ' ' + lastname)
initials = firstname[0] +'.'+ middlename[0] +'.'+lastname [0]
print (initials)
