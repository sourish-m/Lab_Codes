a= 'hello'
b= 'world'

def swap(a,b):
    n = len (b)
    b= b+a
    a= b[0:n]
    b= b[n:]
    print(a+ '\n'+b)
swap (a,b)
    
    
