str1 = input ('Enter the string ')
str2 = ''
for c in str1:
    str2 = c + str2
print (str2)
    
if (str1 == str2):
    print ("Palindrome")
else:
    print ("Not Palindrome")
