str1 = 'Hello'
str2 = 'world'

for c in str1:
    str2 = str2 +c
print (str2)

