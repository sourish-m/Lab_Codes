
from collections import Counter
list1 = [1,1,1,2,3,5,4,3]
print(list1)

result = {k:[k]*n for k,n in Counter(list1).items()}

print(result)
