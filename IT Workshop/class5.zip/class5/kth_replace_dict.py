
list1 = ["a","b","c","d"]
dict1 = {"a" : [5, 6, 7], "b" : [7, 4, 2],}
K = 2
print(list1)
res = [e if e not in dict1 else dict1[e][K]
									for e in list1]

print(res)
