
list1 = [[1,2,3], [5,4,2], [2,3,1]]
print("Matrix is ",list1)

dict1 = {k:n for k,n in enumerate(list1, start=1 )}

print("Result is : ", dict1)
