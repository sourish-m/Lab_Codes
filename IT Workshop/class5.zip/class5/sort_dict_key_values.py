
dict1 = {'this':[2,1], 'is':[2,3,4],'a':[4,5,3],'string':[20,3,10]}
print(dict1)

dict2 = {k:sorted(dict1[k]) for k in sorted(dict1)}

print("After sorting: ",dict2)
