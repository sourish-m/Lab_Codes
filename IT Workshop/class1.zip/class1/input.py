num=100
print (type(num))
