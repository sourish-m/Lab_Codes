number=100
decimalnumber=1000.425
name="Sourish"
print(number)
print(decimalnumber)

