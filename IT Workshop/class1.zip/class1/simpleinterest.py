principal=10000
rate=4
time=5
print ("Simple Interest is")
print (principal*rate*time/100)
