num=1000.01

if num%1==0:
    print ("Integer")
else:
    print ("Float")
