import math
side1=10
side2=15
side3=20
s=(side1+side2+side3)/2
areaoftriangle=math.sqrt(s*(s-side1)*(s-side2)*(s-side3))
print ("Area of triangle is",areaoftriangle)
