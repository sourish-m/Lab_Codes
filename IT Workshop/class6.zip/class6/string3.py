str = input ("Enter a string: ")
str2=""
if (len(str)>3):
	if(str[len(str)-3:len(str)]=="ing"):
		str2=str+"ly"
	else:
		str2=str+"ing"
else:
	str2=str
print ("New String is: ",str2)