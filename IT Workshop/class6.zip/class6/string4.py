str= "this is a test string not poor"
str2=""
a=str.find("not")
b=str.find("poor")
print (a," ",b)
if(str[a+4:a+8]=="poor"):
	str2=str[0:a] + "not good" + str[b+4:len(str)]
print(str2)

