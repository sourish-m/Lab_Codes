str = input ("Enter a string: ")
str2=""
a= str[0]

for i in str:
	if( i== a):
		str2=str2+'$'
	else:
		str2=str2+i
str2=a+str2[1:len(str)]
print("New String is: ",str2)