str= input("Enter a string: ")
if (len(str)<2):
	print (str)
n=len(str)
str2=""
for i in str:
	str2=str[0:2]+str[n-2:n]
print ("New String is: ",str2)

