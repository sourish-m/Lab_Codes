list1=["hello","world","test","python"]
n=0
c=1
for i in list1:
	if (len(i)>n):
		n=len(i)
		c=c+1
print("longest word: ",list1[c],"\nlength: ",n)
		